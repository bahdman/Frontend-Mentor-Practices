let i = 0;
let images = [];
// Images are stored in an array for easier refrence or access by me.

images[0] = "./images/image-product-1.jpg";
images[1] = "./images/image-product-2.jpg";
images[2] = "./images/image-product-3.jpg";
images[3] = "./images/image-product-4.jpg";

document.slide.src = images[0];

const previous = document.getElementById('previous');
const next = document.getElementById('next');
const showcaseImg =document.getElementById('showcase-img');
const showCart = document.getElementById('showCart');
const showCartItems = document.querySelector('.cart-items');
const showCartContent = document.getElementById('cart-content');
const showCartBtn = document.querySelector('.cart-btn');
const showMenu = document.getElementById('menu-show');
const hideMenu = document.getElementById('menu-close');
const slideRight = document.getElementById('slide-right');


// Menu bar
showMenu.addEventListener('click', ()=>{
    slideRight.style.transform = 'translateX(0%)';
    overlay.style.display = 'block';
})

hideMenu.addEventListener('click', ()=>{
    slideRight.style.transform = 'translateX(-150%)';
    overlay.style.display = 'none';
})


//Mobile Slideshow
previous.addEventListener('click', ()=>{
    i--;
    document.slide.src = images[i];
    if(i<0){
        i+=4;
        document.slide.src = images[i];
    }
    
    
})

next.addEventListener('click', ()=>{
    i++;
    document.slide.src = images[i];
    if(i>3){
        i-=4;
        document.slide.src = images[i];
    }
})


// Lighbox display
showcaseImg.addEventListener('click', ()=>{
    overlay.style.display = 'block';
    lightbox.style.display = 'block';
})

// lightbox

// lPbtn --> Lightbox prevoius button
// lNbtn --> Lightbox next button
const lPbtn = document.getElementById('lightbox-previousBtn');
const lNbtn = document.getElementById('lightbox-nextBtn');
const mini_images = document.getElementsByClassName('mini-image');
const close_lightbox = document.getElementById('close-lightbox');
const lightbox = document.getElementById('lightbox-container');
const addItemBtn = document.getElementById('add');
const removeItemBtn = document.getElementById('remove');
const addToCart = document.getElementById('addToCart');
const popup = document.getElementById('pop-up');
const amount = document.querySelectorAll('.amount');
const quantity = document.querySelector('#quantity');
const deleteAllCartItems = document.querySelector('#deleteItems');


close_lightbox.addEventListener('click', ()=>{
    lightbox.style.display = 'none';
    overlay.style.display = 'none';//Try adding keyframe animation to make the transitioning smooth. opacity before display none.

})

function removeMiniOverlay(){
    mini_images[i].classList.remove('mini-overlay');  
}

lPbtn.addEventListener('click', ()=>{
    removeMiniOverlay();
    i--;
    document.lightboxSlide.src = images[i];
    
    if(i<0){
        i+=4;
        document.lightboxSlide.src = images[i];
        mini_images[i].classList.toggle('mini-overlay')
    }
    else{
        mini_images[i].classList.toggle('mini-overlay');
    }   
})

// This sets the mini overlay on the first mini image of the lightbox
mini_images[i].classList.toggle('mini-overlay');

lNbtn.addEventListener('click', ()=>{
    removeMiniOverlay();
    i++;
    document.lightboxSlide.src = images[i];    

    if(i>3){
        i-=4;
        document.lightboxSlide.src = images[i];        
    }

    mini_images[i].classList.toggle('mini-overlay');
    
})



//Desktop Slideshow

let index = 0;
let arraylength = 0;
time = 4000;
arraylength = images.length - 1;

const smallImages = document.querySelectorAll('.pry-mini-image');
const overlay = document.getElementById('overlay');


// The function below removes the min-overlay from previous
// mini-images in the desktop slideshow

function removeOverlay(){
    if(index>=1){
        smallImages[index-1].classList.remove('mini-overlay');
    }else{
        smallImages[index].classList.remove('mini-overlay');
    }
    smallImages[3].classList.remove('mini-overlay')
}

// This Function changes "src" image at a time interval of 4seconds
// Embeded in this function is where the "removeOverlay()" is called.
function imagechange () {
    
    document.imgchange.src = images[index];
    removeOverlay();
    
    smallImages[index].classList.toggle('mini-overlay');
    
    if(index < arraylength){
        index++;
    }else{
        index = 0;
    }
    setTimeout("imagechange()", time);
}


imagechange()


//Cart Functionalities

// Show showCart and hide items

let hideCart = 0;
showCart.addEventListener('click', ()=>{
    showCartItems.style.display = 'block';
    hideCart++;
    
    if((hideCart % 2 ) == 0){
        showCartItems.style.display = 'none';
    }    
})

let increment=0;
function addtoCart(){
    increment++;
    quantity.innerText = increment;
}

function removefromCart(){
    increment--;
    if(increment<=0){
        increment = 0;
        quantity.innerText = increment;        
    }else{
        quantity.innerText = increment;
    }    
}

// Adding Item(s) for purchase
addItemBtn.addEventListener('click',() =>{
    addtoCart()
})

// Removing purchased item(s)
removeItemBtn.addEventListener('click',()=>{
    removefromCart();
})

// Adding items to cart

addToCart.addEventListener('click', ()=>{
    amount.forEach(item => item.innerText = increment); //+quantity 
    popup.style.display = 'block';
    showCartContent.style.display = 'flex';
    showCartBtn.style.display = 'block';

    if(increment<=0){
        popup.style.display = 'none';
        showCartContent.style.display = 'none';
        showCartBtn.style.display = 'none';         
    }
})

// Removing all items from cart

deleteAllCartItems.addEventListener('click', ()=>{
    popup.style.display = 'none';
    showCartContent.style.display = 'none';
    showCartBtn.style.display = 'none';  
})

