const menuBtnOpen = document.getElementById('menu-icon-open');
const menuBtnClose = document.getElementById('menu-icon-close');
const mobileLinks = document.getElementById('mobile-links');

// Show Menu Items
menuBtnOpen.addEventListener('click', ()=>{
    
    mobileLinks.style.display = 'block';
    mobileLinks.classList.add('show-menu');
    menuBtnOpen.style.display = 'none';
    menuBtnClose.style.display = 'block';
    mobileLinks.style.boxShadow = "0px 0px 800px 120px black";
})

// Hide Menu Items

menuBtnClose.addEventListener('click', ()=>{
    mobileLinks.classList.remove('show-menu');
    // mobileLinks.style.display = 'none';
    menuBtnOpen.style.display = 'block';
    menuBtnClose.style.display = 'none';
    mobileLinks.style.boxShadow = "0px 0px 0px 0px";
})